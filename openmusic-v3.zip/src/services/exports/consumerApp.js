// src/services/exports/consumerApp.js
const ConsumerService = require('./consumerService');

console.log('Consumer service started...');
ConsumerService.init();
